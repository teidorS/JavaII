package jdbcPackage;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer")
public class Customer {
	@Id
	private int custid;
	private String password;
	private String rewards;
	private String city;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public Customer(int custid, String password, String rewards, String city) {
		this.custid = custid;
		this.password = password;
		this.rewards = rewards;
		this.city = city;
	}
	public int getCustid() {
		return custid;
	}
	public void setCustid(int custid) {
		this.custid = custid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRewards() {
		return rewards;
	}
	public void setRewards(String rewards) {
		this.rewards = rewards;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", password=" + password + ", rewards=" + rewards + ", city=" + city
				+ "]";
	}
}
