package jdbcPackage;

import java.util.List;

//import java.util.ArrayList;
//import java.util.List;

//import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


public class Dao {
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	  public Customer singleSelect(int id) { 
		 Session session = sessionFactory.openSession();
		 Customer customer = session.get(Customer.class, id);
		 return customer;
	  }
	 
	public void storeEmployee(Customer customer) {
		Session s = sessionFactory.openSession();
		Transaction t = s.beginTransaction();
		s.save(customer);
		t.commit();
		s.close();

	}

	public List<Customer> multiSelect(String ecity) {
		Session session = sessionFactory.openSession();
		Query<Customer> query = session.createQuery("from Customer c where c.city ='"+ecity+"'");

		List<Customer> customers = query.list();
		session.close();
		return customers;
	}
	public void updateCustomer(Customer customer) {
		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();
		session.update(customer);
		t.commit();
		session.close();
	  }
	 public void deleteCustomer(int id) {
		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();
		Query<Customer> query = session.createQuery("delete from Customer c where c.custid =:thisID");
		query.setParameter("thisID", id);
		query.executeUpdate();
		t.commit();
		session.close();
	 }
	 

}
