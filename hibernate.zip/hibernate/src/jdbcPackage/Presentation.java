package jdbcPackage;

import java.util.List;
//import java.util.List;
import java.util.Scanner;

public class Presentation {
	private Dao dao;
	private Customer customer;
	
	Scanner scanner = new Scanner(System.in);
	public void setDao (Dao dao) {
		this.dao = dao;
		this.customer = null;
	}
	
	public void startApp() {
		//singleSelect();
		//insert();
		//multiSelect();
		//deleteCustomer();
		update();
	}

	
	 private void deleteCustomer() { 
		 //customer = dao.singleSelect(5);
		 dao.deleteCustomer(5); 
		
	 }	
	  
	 private void multiSelect() { 
		 System.out.println("Enter city:"); 
		 String city =scanner.nextLine(); 
		 List<Customer> customers = dao.multiSelect(city);
		 if(customers.size()==0) 
			 System.out.println("No customer loacated in "+city);
		 else 
			 System.out.println(customers);
	 }
	 
	 private void update() { 
		 customer = dao.singleSelect(44);
		 customer.setCity("Bangalore");
		 dao.updateCustomer(customer);
	 }
}
