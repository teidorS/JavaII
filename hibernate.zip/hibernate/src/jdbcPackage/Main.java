package jdbcPackage;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext cp = new ClassPathXmlApplicationContext("jdbcConfig.xml");
		Presentation presentation = cp.getBean(Presentation.class);
		presentation.startApp();
	}
}
